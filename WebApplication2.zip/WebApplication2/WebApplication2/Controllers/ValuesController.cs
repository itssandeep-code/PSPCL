﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
       [HttpGet]
        public IHttpActionResult LoadFile(string sourceId, string extension)
        {
            string folderName = GetFolderNameBySourceId(Convert.ToInt32(sourceId));            
            //Get file path
            string directoryPath = string.Format(@"{0}\{1}", ConfigurationManager.AppSettings["DirectoryPath"], folderName);
            if (Directory.Exists(directoryPath))
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(directoryPath);
                FileInfo files = directoryInfo.GetFiles()
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault(x => x.Extension.Contains(extension));

                if (files != null)
                {
                    // var dataStream=new MemoryStream( System.IO.File.ReadAllBytes(files.FullName));
                   // return ResponseMessage(System.IO.File.ReadAllBytes(files.FullName),"","");
                    var result = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new ByteArrayContent(System.IO.File.ReadAllBytes(files.FullName))
                    };
                    result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                    {
                        FileName = files.Name
                    };
                    result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

                    var response = ResponseMessage(result);

                    return response;
                }
                return NotFound();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPost]
        public LoginResponse Login( LoginModel lgn)
        {
            LoginResponse response = new LoginResponse();
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["PSPCLDB"].ToString());
                SqlCommand cmd = new SqlCommand();
                SqlDataAdapter adp = null;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "select u.SourceId,s.Name From Users u join Source s on u.SourceId=s.ID WHERE UserName ='" + lgn.UserName.Trim() + "' and Password=" + lgn.Password.Trim();
                cmd.Connection = con;
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                   response.SourceId = Convert.ToInt32(sdr["SourceId"]);
                    response.SourceName = Convert.ToString(sdr["Name"]);
                }
                con.Close();
            }
            catch(Exception ex)
            {
            }
            return response;
        }
        [HttpGet]
        public List<LoginResponse> GetAllSources()
        {
           List<LoginResponse> response = new List<LoginResponse>();
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["PSPCLDB"].ToString());
                SqlCommand cmd = new SqlCommand();
                //SqlDataAdapter adp = null;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "select u.SourceId,s.Name From Users u join Source s on u.SourceId=s.ID ";
                cmd.Connection = con;
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    LoginResponse lg = new LoginResponse();
                    lg.SourceId = Convert.ToInt32(sdr["SourceId"]);
                    lg.SourceName = Convert.ToString(sdr["Name"]);
                    response.Add(lg);
                }
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return response;
        }
        private string GetFolderNameBySourceId(int sourceId)
        {
            string response = string.Empty;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["PSPCLDB"].ToString());
                SqlCommand cmd = new SqlCommand();
                SqlDataAdapter adp = null;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "select u.Folder From Users u where u.SourceId=" + sourceId ;
                cmd.Connection = con;
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    response = Convert.ToString(sdr["Folder"]);
                  
                }
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return response;
        }
    }
}
